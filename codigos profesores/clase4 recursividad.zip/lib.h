int getInt(int* resultado,
           char* mensaje,
           char* mensajeError,
           int minimo,
           int maximo,
           int reintentos);

int factorial(int numero, long* resultado);
long factorial2(int numero);
